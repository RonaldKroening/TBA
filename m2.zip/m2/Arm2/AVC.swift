//
//  AVC.swift
//  Arm2
//
//  Created by Bianca on 2/17/20.
//  Copyright © 2020 Rift Labs. All rights reserved.
//

import Foundation
import UIKit

class AVC : UIViewController{
    struct global{
        static var s: String = String()
    }
}


