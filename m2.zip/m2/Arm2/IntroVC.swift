//
//  IntroVC.swift
//  Arm2
//
//  Created by Bianca on 3/20/20.
//  Copyright © 2020 Rift Labs. All rights reserved.
//

import Foundation
import UIKit
class IntroVC: UIViewController{
    
override func viewDidLoad() {
        super.viewDidLoad()

    }
 
      override func didReceiveMemoryWarning() {
          super.didReceiveMemoryWarning()
      }
}

