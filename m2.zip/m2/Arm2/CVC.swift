//
//  CVC.swift
//  Arm2
//
//  Created by Bianca on 3/1/20.
//  Copyright © 2020 Rift Labs. All rights reserved.
//

import Foundation

import UIKit
import Foundation
class CVC: UICollectionViewCell {

    
    @IBOutlet weak var lab1: UILabel!
    
    @IBOutlet weak var imView1: UIImageView!
    
   

}
