//
//  CVC.swift
//  Arm2
//
//  Created by Bianca on 2/16/20.
//  Copyright © 2020 Rift Labs. All rights reserved.
//

import UIKit
import PDFKit
import Foundation
class CollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var title: UILabel!
    
    @IBOutlet weak var pV: UIImageView!
    
    
    
    
   

}
